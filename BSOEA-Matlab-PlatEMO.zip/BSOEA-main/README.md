# A tri-objective method for bi-objective feature selection in classification
This is the BSOEA code for solving multi-objective feature selection problems in classification.
