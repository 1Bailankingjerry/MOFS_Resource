Genetic Programming for Automatically Evolving Multiple Features to Classification

We are more than happy to share the related work with you. If you do some further studies based on this research work, please cite this study as a reference in your papers.

Please feel free to contact me if you have any questions or comments (wpeng@zzu.edu.cn).
