sbatch job8.sl dataSet_WBCD
sbatch job8.sl dataSet_ion
sbatch job8.sl dataSet_move
sbatch job8.sl dataSet_hill
sbatch job8.sl dataSet_musk1
sbatch job8.sl dataSet_arrhythmia
sbatch job8.sl dataSet_madelon
# sbatch job8.sl dataSet_AD
# sbatch job8.sl dataSet_leukemia
# sbatch job8.sl dataSet_leukemia1
# sbatch job8.sl dataSet_ALL
# sbatch job8.sl dataSet_CLL
# sbatch job8.sl dataSet_Darwin
# sbatch job8.sl dataSet_DrivFace
# sbatch job8.sl dataSet_QSAR_rogen
# sbatch job8.sl dataSet_TCGA

