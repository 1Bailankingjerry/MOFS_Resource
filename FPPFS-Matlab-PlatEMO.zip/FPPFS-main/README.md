# FPPFS
# Learning to Preselection: A Filter-Based Performance Predictor for Multiobjective Feature Selection in Classification

# Acknowledge
Please kindly cite this paper in your publications if it helps your research:
```
@article{jiao2024learning,
  title={Learning to Preselection: A Filter-Based Performance Predictor for Multiobjective Feature Selection in Classification},
  author={Jiao, Ruwang and Xue, Bing and Zhang, Mengjie},
  journal={IEEE Transactions on Evolutionary Computation},
  year={2024},
  publisher={IEEE}
}
```
