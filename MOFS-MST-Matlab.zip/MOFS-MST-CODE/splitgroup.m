function newg = splitgroup(g)

groupNum = numel(g);

c=1;

for j = 1 : groupNum
    n= numel(g{j});
    
    if n < 2
        newg{c} = g{j};
        c=c+1;
    else
        n2 = floor(n / 2);
        gt = g{j};
        newg{c} = gt(1 : n2);
        newg{c + 1} = gt(n2 + 1 : n);
        c=c+2;
    end
end
end