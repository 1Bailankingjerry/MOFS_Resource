function fit = fitness1(xtrain, ytrain, xvalid,yvalid,X)
%% Calculate Objective Values

% LOOCV
% KNN, k = 1

k=5;
My_Model = fitcknn(xtrain,ytrain,'NumNeighbors',k);
% Prediction
pred     = predict(My_Model,xvalid);
% Accuracy
Acc      = sum(pred == yvalid) / length(yvalid);
error=1 - Acc;
fit = [error, sum(X)];
end