function pop2 = GA11(parent,D,assess,Rank)

[N,~]=size(parent);
m=N/2;
p=1;

%% map group to full feature space


[newN,~]=size(parent);

for i=1:m
    % Select the first parent
    p1 = round(newN*rand(1));
    if p1 < 1
        p1 = 1;
    end

    if sum(parent(p1,:))==0
        p1 = round(newN*rand(1));
        if p1 < 1
            p1 =1 ;
        end
    end
    % Select the second parent
    p2 = round(newN*rand(1));
    if p2 < 1
        p2 = 1;
    end
    if sum(parent(p2,:))==0
        p2 = round(newN*rand(1));
        if p2 < 1
            p2 =1 ;
        end
    end
    % Make sure both the parents are not the same.
    while isequal(parent(p1,:),parent(p2,:))
        p2 = round(newN*rand(1));
        if p2 < 1
            p2 = 1;
        end
    end
    p1 = parent(p1,:);
    p2 = parent(p2,:);
    child_1(i,:)= p1;
    child_2(i,:)= p2;
    k = find(xor(p1, p2));
    t = length(k);
    if t > 1
        for j=1:t

%             if rand(1)>(Rank(k(j),1)+Rank(k(j),2))/(2*D)
            if rand(1)<0.5

                child_1(i, k(j)) = 1;
                child_2(i, k(j)) = 0;
            else
                child_1(i, k(j)) = 0;
                child_2(i, k(j)) = 1;
            end
        end

    end
end

for i=1:m

    j1 = find(child_1(i, :));
    j0 = find(~child_1(i, :));
    k1 = rand(1, length(j1)) < 1/D;
    child_1(i, j1(k1)) = 0;
    k0 = rand(1, length(j0)) <1/D;
    child_1(i, k0) = 1;
    %

    j11 = find(child_2(i, :));
    j00 = find(~child_2(i, :));
    k11 = rand(1, length(j11)) < 1/D;
    child_2(i, j11(k11)) = 0;
    k0 = rand(1, length(j00)) <1/D;
    child_2(i, k0) = 1;
    pop2(p,:)=child_1(i,:);
    pop2(p+1,:)=child_2(i,:);
    p=p+2;
end

% f=sum(pop2);
% f_a1=find(f==N);
% f_a0=find(f==0);
% if isempty(f_a1)==0
%     for i=length(f_a1)
%         for j=1:N
%             if rand(1)<0.2
%                 pop2(j,f_a1(i))=0;
%             end
%         end
%     end
% end
% 
% 
% if isempty(f_a0)==0
%     for i=length(f_a0)
%         for j=1:N
%             if rand(1)<0.02
%                 pop2(j,f_a0(i))=1;
%             end
%         end
%     end
% end

end
