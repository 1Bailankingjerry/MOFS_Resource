function [pop1,pop2,g1,g2] = AdjustG(g1,g2,pop1,pop2,featNum,assess,objs1,objs2,Rank)

Lg1=numel(g1);
Lg2=numel(g2);
popNum=size(pop1, 1);
x1=group_x(g1,pop1,featNum);
x2=group_x(g2,pop2,featNum);
[FrontNo1, ~] = NDSort(objs1,size(objs1, 1));
WorseF1 =  FrontNo1' == max(FrontNo1);
FworseP1=find(WorseF1==1);
NNF1=FrontNo1' ~= 1;
% nnfP1=find(NNF1==1);
% nnfP1=find(objs1(:,1)~=min(objs1(:,1)));

ff1=NNF1-WorseF1;
fff1=find(ff1==1);

[FrontNo2, ~] = NDSort(objs2,size(objs2, 1));
WorseF2 =  FrontNo2' == max(FrontNo2);
FworseP2=find(WorseF2==1);

NNF2=FrontNo2' ~= 1;
% nnfP2=find(NNF2==1);
% nnfP2=find(objs2(:,1)~=min(objs2(:,1)));
ff2=NNF2-WorseF2;
fff2=find(ff2==1);

s1=sum(pop1);
fs1_0=find(s1==0); %%%%找到所有个体都不选择的组
c1=1;
if isempty(fs1_0)==0
    for i=1:length(fs1_0)

        a1=g1{1,fs1_0(i)};  %%找到g1中所有个体不选择的组中的特征放到a1中
        if length(a1)>1
            f2=x2(:,a1');  %%a1中的特征在第二个种群中的情况
            sf2=sum(f2);  %%计算这些特征在第二个种群中有多少个个体选中
            fsf2_0=find(sf2==0); %%%找到第二个种群也不选择a1中的特征

            if length(a1)>length(fsf2_0)
                if isempty(fsf2_0)==0
                    adjf=a1(fsf2_0,:);  %%将这些特征设置为调整组
                    g1{1,fs1_0(i)}(fsf2_0,:)=[];
                    g1{1,Lg1+c1}=adjf;
                    pop1(:,Lg1+c1)=0;
                    p11=(mean(Rank(adjf,1))+mean(Rank(adjf,2)))/(2*featNum);
                    for j= 1:length(FworseP1)
                        if rand(1)>0
                            pop1(FworseP1(j),Lg1+c1)=1;

                        else
                            pop1(FworseP1(j),Lg1+c1)=0;

                        end
                    end
                    c1=c1+1;
                end

%                 aa1=g1{1,fs1_0(i)};
%                 p1=(mean(Rank(aa1,1))+mean(Rank(aa1,2)))/(2*featNum);
%                 for j= 1:length(FworseP1)
%                     if rand(1)<p1
% %                                                 pop1(j,fs1_0(i))=1;
%                         pop1(FworseP1(j),fs1_0(i))=1;
%                     else
% %                                                 pop1(j,fs1_0(i))=0;
%                         pop1(FworseP1(j),fs1_0(i))=0;
%                     end
% 
%                 end

            end
        end

    end

end

s2=sum(pop2);
fs2_0=find(s2==0);
c2=1;
if isempty(fs2_0)==0
    for i=1:length(fs2_0)

        a2=g2{1,fs2_0(i)};  %%找到g1中所有个体不选择的组中的特征放到a1中
        if length(a2)>1
            f1=x1(:,a2');  %%a1中的特征在第二个种群中的情况
            sf1=sum(f1);  %%计算这些特征在第二个种群中有多少个个体选中
            fsf1_0=find(sf1==0); %%%找到第二个种群也不选择a1中的特征


            if length(a2)>length(fsf1_0)
                if isempty(fsf1_0)==0
                    adjf=a2(fsf1_0,:);  %%将这些特征设置为调整组
                    g2{1,fs2_0(i)}(fsf1_0,:)=[];

                    g2{1,Lg2+c2}=adjf;
                    pop2(:,Lg2+c2)=0;
                    p22=(mean(Rank(adjf,1))+mean(Rank(adjf,2)))/(2*featNum);
                    for j= 1:length(FworseP2)
                        if rand(1)>0
                            pop2(FworseP2(j),Lg2+c2)=1;
   
                        else
                            pop2(FworseP2(j),Lg2+c2)=0;

                        end
                    end
                    c2=c2+1;
                end

%                 aa2=g2{1,fs2_0(i)};
%                 p2=(mean(Rank(aa2,1))+mean(Rank(aa2,2)))/(2*featNum);
%                 for j= 1:length(FworseP2)
%                     if rand(1)<p2
% %                                                 pop2(j,fs2_0(i))=1;
%                         pop2(FworseP2(j),fs2_0(i))=1;
% 
%                     else
% %                                                 pop2(j,fs2_0(i))=0;
%                         pop2(FworseP2(j),fs2_0(i))=0;
%                     end
% 
% 
%                 end

            end
        end

    end

end

end
