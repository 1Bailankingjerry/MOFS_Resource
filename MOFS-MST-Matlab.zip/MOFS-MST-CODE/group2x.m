function x = group2x(g1,g2,pop1,pop2)
	%% map group to full feature space
% 	x = zeros(popNum,1, featNum);
	for i = 1 : size(pop1, 1)
		for j = 1 : size(g1, 2)
			x(i, g1{j}) = pop1(i, j);
		end
	end
	for i = 1 : size(pop2, 1)
		for j = 1 : size(g2, 2)
			x(size(pop1, 1)+i, g2{j}) = pop2(i, j);
		end
    end
end