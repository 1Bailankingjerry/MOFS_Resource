function [g,g2,MaxFNo,len2] = divide_g(rank)
[FrontNo,MaxFNo] = NDSort(rank,size(rank, 1));
for i=1:MaxFNo
    g2{i}=find(FrontNo==i)';
end

len2=MaxFNo;
idx = kmeans(rank, len2);
idx = idx';
for i = 1 : len2
    g{i} = find(idx == i)';
end

end