function [pop1,pop2,Se1,Se2]=popInitial(g1,g2,assess)
for i=1:numel(g1)
    T1(1,i)=(mean(assess(g1{i},1))+mean(assess(g1{i},2)))/2;
end
for i=1:numel(g2)
    T2(1,i)=(mean(assess(g2{i},1))+mean(assess(g2{i},2)))/2;
end
for i=1:50
    pop1(i,:) = rand(1, length(g1)) < T1;
    pop2(i,:) = rand(1, length(g2)) < T2;
end
    Se1=50;
    Se2=50;
end