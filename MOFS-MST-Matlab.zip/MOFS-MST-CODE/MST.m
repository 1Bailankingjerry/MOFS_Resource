function [pfs, errTr, selFeatNum] = MST(data, label, dataName, fold)
%% Init
k_z=5;
indices = crossvalind('Kfold', size(data,1), k_z);
featNum = size(data, 2);
maxIt = 100;		% the max number of iterations
Vt = 10;		% the value of alpha
popNum = 100;		% poplation size
maxIt2=15;
archive = [];
archiveObjs = [];
archiveNum = popNum;

eg=[];

diance1=featNum;
diance2=featNum;
panduan1=0;
panduan2=0;

num1=0;
num2=0;

% group
[r44,r2,assess] = SortFeature(data, label);
Rank=[r44,r2'];
for i=1:featNum
    rank1(i)=find(r44==i);
    rank2(i)=find(r2==i);
end
rank=[rank1' rank2'];
[g1,g2,len1,len2]=divide_g(rank);
[pop1,pop2,Se1,Se2]=popInitial(g1,g2,assess);
x = group2x(g1,g2,pop1,pop2);
objs = CalcObjs(data, label, x,indices);  %feature submit evaluation
% firstStageEnd = maxIt2 * floor(log2(featNum / len1) +1 );
objs_1=objs(1:Se1,:);
objs_2=objs(Se1+1:end,:);
[FrontNo, ~] = NDSort(objs_1,size(objs_1, 1));
Front1 =  FrontNo' == 1;
[FrontNo, ~] = NDSort(objs_2,size(objs_2, 1));
Front2 =  FrontNo' == 1;

F_objs1=objs_1(Front1,:);
F_objs2=objs_2(Front2,:);

xx1=sum(F_objs1(:,1))/sum(Front1);
yy1=sum(F_objs1(:,2))/sum(Front1);
zhixin1=[xx1,yy1];
xx2=sum(F_objs2(:,1))/sum(Front2);
yy2=sum(F_objs2(:,2))/sum(Front2);
zhixin2=[xx2,yy2];


firstStageEnd=fix(maxIt/maxIt2)*maxIt2;

if mod(maxIt,maxIt2)==0
    firstStageEnd=(fix(maxIt/maxIt2)-1)*maxIt2;
end

pr=1;

for it=2: maxIt
%     if it < firstStageEnd
    if num1<=3 && num2 <=3
        %     if numel(g1) ~= featNum || numel(g2) ~= featNum

        tour = 2;
        parent1 = tournament_selection(pop1, popNum/2, tour);
        parent2 = tournament_selection(pop2, popNum/2, tour);
        pop_1 = Final_GA1(parent1,g1,assess,featNum,Rank);

        pop_2 = Final_GA1(parent2,g2,assess,featNum,Rank);

        x = group2x(g1,g2,pop_1,pop_2);
        objs2 = CalcObjs(data, label, x,indices);

        [pop1, objs_1] = EnvironmentalSelection([pop1; pop_1],  [objs(1:Se1,:); objs2(1:Se1,:)], Se1);
        [pop2, objs_2] = EnvironmentalSelection([pop2; pop_2],  [objs(Se1+1:end,:); objs2(Se1+1:end,:)], Se2);
     

        objs=[objs_1;objs_2];

        x = group2x(g1,g2,pop1,pop2);

        [FrontNo, ~] = NDSort(objs_1,size(objs_1, 1));
        Front1 =  FrontNo' == 1;
        [FrontNo, ~] = NDSort(objs_2,size(objs_2, 1));
        Front2 =  FrontNo' == 1;

        xia_zhixin1=zhixin1;
        xia_zhixin2=zhixin2;
        F_objs1=objs_1(Front1,:);
        F_objs2=objs_2(Front2,:);

        xx1=sum(F_objs1(:,1))/sum(Front1);
        yy1=sum(F_objs1(:,2))/sum(Front1);
        zhixin1=[xx1,yy1];



        xx2=sum(F_objs2(:,1))/sum(Front2);
        yy2=sum(F_objs2(:,2))/sum(Front2);
        zhixin2=[xx2,yy2];

        diance1=norm(zhixin1-xia_zhixin1);
        diance2=norm(zhixin2-xia_zhixin2);

        if diance1==0
            num1=num1+1;
        elseif diance1>log10(featNum)
           
            num1=0;
        end
        if diance2==0
            num2=num2+1;
        elseif diance2>log10(featNum)
           
            num2=0;
        end


  

        if diance1==0

            [archive, archiveObjs] = UpdateArchive(x, objs, archive, archiveObjs, archiveNum);

            [pop1,pop2,g1,g2,eg] = KLgroup1(g1,g2,objs_1,objs_2,pop1,pop2,featNum,eg);

            x1=group_x(g1,pop1,featNum);
            x2=group_x(g2,pop2,featNum);

            objs = CalcObjs(data, label, [x1;x2],indices);

            tour = 2;
            parent1 = tournament_selection(pop1, popNum/2, tour);
            parent2 = tournament_selection(pop2, popNum/2, tour);
            pop_1 = GA1(parent1,g1,assess,featNum,Rank);

            pop_2 = GA1(parent2,g2,assess,featNum,Rank);

            x_1=group_x(g1,pop_1,featNum);
            x_2=group_x(g2,pop_2,featNum);

            objs2 = CalcObjs(data, label, [x_1;x_2],indices);



            [pop1, objs_1] = EnvironmentalSelection([pop1; pop_1],  [objs(1:Se1,:); objs2(1:Se1,:)], Se1);
            [pop2, objs_2] = EnvironmentalSelection([pop2; pop_2],  [objs(Se1+1:end,:); objs2(Se1+1:end,:)], Se2);


            objs=[objs_1;objs_2];
            x = group2x(g1,g2,pop1,pop2);


        elseif diance2==0


            [pop1,pop2,g1,g2,eg] = KLgroup(g1,g2,objs_1,objs_2,pop1,pop2,featNum,eg);

            x1=group_x(g1,pop1,featNum);
            x2=group_x(g2,pop2,featNum);

            objs = CalcObjs(data, label, [x1;x2],indices);

            tour = 2;
            parent1 = tournament_selection(pop1, popNum/2, tour);
            parent2 = tournament_selection(pop2, popNum/2, tour);
            pop_1 = GA1(parent1,g1,assess,featNum,Rank);

            pop_2 = GA1(parent2,g2,assess,featNum,Rank);

            x_1=group_x(g1,pop_1,featNum);
            x_2=group_x(g2,pop_2,featNum);

            objs2 = CalcObjs(data, label, [x_1;x_2],indices);



            [pop1, objs_1] = EnvironmentalSelection([pop1; pop_1],  [objs(1:Se1,:); objs2(1:Se1,:)], Se1);
            [pop2, objs_2] = EnvironmentalSelection([pop2; pop_2],  [objs(Se1+1:end,:); objs2(Se1+1:end,:)], Se2);


            objs=[objs_1;objs_2];
            x = group2x(g1,g2,pop1,pop2);

        end
           disp(strcat("MPG on ", dataName, " Fold ", num2str(fold), " Iter ", num2str(it)));
           [archive, archiveObjs] = UpdateArchive(x, objs, archive, archiveObjs, archiveNum);

    else

        tour = 2;
        parent = tournament_selection(x, popNum/2, tour);

        x_1=GA11(parent,featNum,assess,Rank);
        objs2 = CalcObjs(data, label, x_1,indices);
        [x, objs] = EnvironmentalSelection([x;x_1],  [objs; objs2], popNum);

        [archive, archiveObjs] = UpdateArchive(x, objs, archive, archiveObjs, archiveNum);
        disp(strcat("MPG on ", dataName, " Fold ", num2str(fold), " Iter ", num2str(it)));

    end
end
pf = [archiveObjs;objs];
pfs =[archive;x];
errTr = pf(:, 1);
selFeatNum = pf(:, 2);


end


function [r44,fs_r2,assess] = SortFeature(data, label)
% Get infomation from dataset
[k,~]=size(data);
curPath = pwd;
path(path, [curPath filesep 'lib']);
path(path, [curPath filesep 'lib' filesep 'weka']);
loadWeka(['lib' filesep 'weka']);
m = k;
[out] = fsReliefF(data, label, k, m);
[out.fList fs_r2] = sort(out.W,'descend');

[su, ent] = GetSU(data, label);
[~, r44] = sort(su, 'descend');

su = (su - min(su)) ./ (max(su) - min(su));
w=(out.W-min(out.W))./(max(out.W) - min(out.W));
assess=[su ,w'];
end

function [su, ent] = GetSU(x, y)

su = zeros(size(x, 2), 1);
ent = zeros(size(x, 2), 1);
for i = 1 : size(x, 2)
    [su(i), ent(i)] = MItest(x(:, i), y);
end

end

function [mi, Ha] = MItest(a,b)
%culate MI of a and b in the region of the overlap part

%计算重叠部分
[Ma,Na] = size(a);
[Mb,Nb] = size(b);
M=min(Ma,Mb);
N=min(Na,Nb);

%初始化直方图数组
hab = zeros(256,256);
ha = zeros(1,256);
hb = zeros(1,256);

%归一化
if max(max(a))~=min(min(a))
    a = (a-min(min(a)))/(max(max(a))-min(min(a)));
else
    a = zeros(M,N);
end

if max(max(b))-min(min(b))
    b = (b-min(min(b)))/(max(max(b))-min(min(b)));
else
    b = zeros(M,N);
end

a = double(int16(a*255))+1;
b = double(int16(b*255))+1;

%统计直方图
for i=1:M
    for j=1:N
        indexx =  a(i,j);
        indexy = b(i,j) ;
        hab(indexx,indexy) = hab(indexx,indexy)+1;%联合直方图
        ha(indexx) = ha(indexx)+1;%a图直方图
        hb(indexy) = hb(indexy)+1;%b图直方图
    end
end

%计算联合信息熵
hsum = sum(sum(hab));
index = find(hab~=0);
p = hab/hsum;
Hab = sum(sum(-p(index).*log(p(index))));

%计算a图信息熵
hsum = sum(sum(ha));
index = find(ha~=0);
p = ha/hsum;
Ha = sum(sum(-p(index).*log(p(index))));

%计算b图信息熵
hsum = sum(sum(hb));
index = find(hb~=0);
p = hb/hsum;
Hb = sum(sum(-p(index).*log(p(index))));

%计算a和b的互信息
mi = Ha+Hb-Hab;

%计算a和b的归一化互信息
mi = 2 * mi /(Ha+Hb);
end

function [archive, archiveObjs] = UpdateArchive(pop, fit, archive, archiveObjs, archiveNum)

[FrontNo, ~] = NDSort(fit,size(fit, 1));
idx = min(fit(:, 1)) == fit(:, 1);
idx = idx | FrontNo' == 1;
archive = [archive; pop(idx, :)];
archiveObjs = [archiveObjs; fit(idx, :)];
[archive, archiveObjs] = duplicate(archive, archiveObjs);

if size(archive,1) > archiveNum
    [FrontNo, MaxFNo] = NDSort(archiveObjs,archiveNum);
    Next = FrontNo < MaxFNo;
    CrowdDis = CrowdingDistance(archiveObjs,FrontNo);
    Last     = find(FrontNo==MaxFNo);
    [~,Rank] = sort(CrowdDis(Last),'descend');
    Next(Last(Rank(1:archiveNum-sum(Next)))) = true;
    archive = archive(Next, :);
    archiveObjs = archiveObjs(Next, :);
end

% 	[archive, archiveObjs] = duplicate(archive, archiveObjs);
end

function [pop, fit] = duplicate(pop, fit)

m = size(pop, 1);
dup = zeros(m, 1);
d = zeros(m, m);
lens = sum(pop, 2);
for i = 1 : m
    for j = i + 1 : m
        d(i, j) = sum(pop(i, :) + pop(j, :) == 2);
        if d(i, j) == min(lens(i), lens(j))
            if fit(i, 1) > fit(j, 1)
                dup(i) = 1;
            elseif fit(i, 1) < fit(j, 1)
                dup(j) = 1;
            else
                if lens(i) > lens(j)
                    dup(i) = 1;
                else
                    dup(j) = 1;
                end
            end
        end
    end
end

pop = pop(dup == 0, :);
fit = fit(dup == 0, :);

end
