function [pop1,pop2,g1,g2,objs_1,objs_2] = DDgroup(g1,g2,objs_1,objs_2,pop1,pop2,featNum)
x1=group_x(g1,pop1,featNum);
x2=group_x(g2,pop2,featNum);

bestX1=min(objs_1(:,1));
P1=find(objs_1(:,1)==bestX1);
num1=objs_1(P1,2);
bestX2=min(objs_2(:,1));
P2=find(objs_2(:,1)==bestX2);
num2=objs_2(P2,2);

if bestX1(1,1) < bestX2(1,1)
    minN1=find(num1==min(num1));
    bestP1=P1(minN1,:);
    bestpop1=x1(bestP1(1,1),:);

    maxObj2=max(objs_2(:,1));
    maxP2=find(objs_2(:,1)==maxObj2);

    [g2,x2]=Ad_Group(bestpop1,g2,x2,maxP2(1,1));
    
    pop2=x_group(g2,x2);

    objs_2(maxP2(1,1),:)=objs_1(bestP1(1,1),:);
elseif bestX1(1,1) > bestX2(1,1)
    minN2=find(num2==min(num2));
    bestP2=P2(minN2,:);
    bestpop2=x2(bestP2(1,1),:);
    
    maxObj1=max(objs_1(:,1));
    maxP1=find(objs_1(:,1)==maxObj1);

        
    
    [g1,x1]=Ad_Group(bestpop2,g1,x1,maxP1(1,1));
    objs_1(maxP1(1,1),:)=objs_2(bestP2(1,1),:);
    
    pop1=x_group(g1,x1);

elseif bestX1(1,1) == bestX2(1,1)
    if min(num1)<min(num2)
        minN1=find(num1==min(num1));
        bestP1=P1(minN1,:);
        bestpop1=x1(bestP1(1,1),:);

        maxObj2=max(objs_2(:,1));
        maxP2=find(objs_2(:,1)==maxObj2);


        [g2,x2]=Ad_Group(bestpop1,g2,x2,maxP2(1,1));
        objs_2(maxP2(1,1),:)=objs_1(bestP1(1,1),:);

        pop2=x_group(g2,x2);
    elseif min(num1)>min(num2)
        minN2=find(num2==min(num2));
        bestP2=P2(minN2,:);
        bestpop2=x2(bestP2(1,1),:);

        maxObj1=max(objs_1(:,1));
        maxP1=find(objs_1(:,1)==maxObj1);


        [g1,x1]=Ad_Group(bestpop2,g1,x1,maxP1(1,1));
        objs_1(maxP1(1,1),:)=objs_2(bestP2(1,1),:);
        pop1=x_group(g1,x1);

    end
 




end


end