function fit = CalcObjs(data, label, X,indices)
%% Calculate Objective Values

X = X > 0;

m = size(X, 1);
fit = zeros(m, 2);
parfor i = 1 : m
    fit(i, :) = KNN(data, label, X(i, :),indices);
end

end

function fit = KNN(data, label, X,indices)
% LOOCV
% KNN, k = 1
k=5;
if sum(X) > 0
%     k_z=5;
%     indices = crossvalind('Kfold', size(data,1), k_z);
    for i = 1:5
        testIdx = indices == i;
        trainIdx = ~testIdx;
        xtrain = data(trainIdx,:);%提取训练数据
        xvalid  = data(testIdx,:);%提取验证数据
        ytrain  = label(trainIdx);
        yvalid  = label(testIdx);
        
        My_Model = fitcknn(xtrain(:,X),ytrain,'NumNeighbors',k);
        % Prediction
        pred     = predict(My_Model,xvalid(:,X));
        % Accuracy
        Acc      = sum(pred == yvalid) / length(yvalid);
        % Error rate
        E(i) =1 - Acc;
    end
    error = mean(E);
    fit = [error, sum(X)];
    
else
    fit = [1, size(data, 2)];
end
end