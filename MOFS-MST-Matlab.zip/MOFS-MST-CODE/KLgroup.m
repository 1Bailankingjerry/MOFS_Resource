function [pop1,pop2,g1,g2,eg] =  KLgroup(g1,g2,objs_1,objs_2,pop1,pop2,featNum,eg)

sg1=sum(pop1);


[out1,ff1] = sort(sg1,'descend');


m1=1;
xia1=0;
if isempty(eg)==0
    while xia1<1
        %     xia1=0;
        f1=ff1(1,m1);

        Msg11=g1{1,f1};


        a1=min(length(eg),length(Msg11));

        for j=1:a1
            b1=find(eg==Msg11(j));
            if isempty(b1)==1
                xia1=xia1+1;
                Msg1{1,xia1}=g1{1,f1};
            end
        end
        m1=m1+1;
    end
else
    m1=1;
    for i=1:m1
        f1=ff1(1,i);
        Msg1{1,i}=g1{1,f1};
    end
end


F2=zeros(1,featNum);



len2=numel(g2);




for i=1:len2
    F2(1,g2{i})=i;
end



c=1;
for j=1:numel(Msg1)
    ktg2=Msg1{1,j};
    for i=1:length(ktg2)
        a2=F2(1,ktg2(i));
        n2=find(F2==a2);
        if length(n2)>1
            F2(1,ktg2(i))=len2+c;
        end
    end
    re2=find(F2==len2+c);
    if isempty(re2)==0
        c=c+1;
    end
end




for i=1:max(F2)

    g2{i}=find(F2==i)';

end



[FrontNo2, ~] = NDSort(objs_2,size(objs_2, 1));
NNF2=FrontNo2' ~= 1;


if numel(g2)>len2
    addg2=numel(g2)-len2;
    for i=1:addg2
        pop2(NNF2,len2+i)=1;
    end
end
for i=1:numel(Msg1)
    eg=[eg;Msg1{1,i}];
end
[~, uni] = unique(eg, 'rows');
eg=eg(uni,:);

end


