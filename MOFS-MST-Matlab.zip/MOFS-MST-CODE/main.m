%%
clc;
clear;
close all;

dataNames = {'GLIOMA','Leukemia1','9Tumor','Brain1','Carcinom','nci9','Brain2','Leukemia2','11Tumor','GLI_85','acrene','tumors_C'};
for dN = 1:length(dataNames)
    addpath(genpath(cd));

    all_testPF=[];
    HV_MOEA=[];

    for ci=1:30

        rand('seed',ci);


        if ci>1
            load (strcat('result-', dataNames{dN}, '-', 'HV_PF'));
        end



        %         disp(dataName);

        load(dataNames{dN});
        X = full(X);
        [m, featNum] = size(X);
        S_ple=size(X,1);  % 计算数据集特征数和类别数
        Lei=unique(Y);
        for i=1:length(Lei)
            ind{i}=find(Y==Lei(i));
            tr_ind{i}=ind{i}(1:floor(length(ind{i})*0.7));
            train_ind(1:length(tr_ind{1,i}),i)=tr_ind{1,i};
            te_ind{i}=setxor(tr_ind{i},ind{i});
            test_ind(1:length(te_ind{1,i}),i)=te_ind{1,i};
        end
        TT=train_ind(train_ind~=0); % 划分训练集
        testData=X(setdiff(1:S_ple,TT),:);
        testLabel = Y(setdiff(1:S_ple,TT), :);
        trainData=X(TT,:);
        trainLabel = Y(TT, :);


        tic;
        t1 = clock;
        [x, err, selFeatNum] = MST(trainData, trainLabel, dataNames{dN}, 5);
        x=logical(x);
        for i=1:size(x,1)
            xx=x(i,:);
            if sum(xx)>0
                fit(i,:)= fitness1(trainData(:,xx),trainLabel, testData(:,xx),testLabel,xx);
            else
                fit(i,1)=1;
                fit(i,2)=featNum;
            end
        end
        fit=unique(fit(:,1:2),'row');
        [FrontNo, ~] = NDSort(fit,size(fit, 1));
        Front1 =  FrontNo' == 1;
        testPF=fit(Front1,: );
        testPF(:,2)=testPF(:,2)/featNum;
        figure(1)
        scatter(testPF(:,1),testPF(:,2),'r');
        repoint=[1,1];
        HV=Hypervolume_calculation(testPF,repoint);
        HV_MPG(ci)=HV;
        mean_HV_MPG=mean(HV_MPG);
        std_HV_MPG=std(HV_MPG);
        Acc=1-testPF(:,1);
        Acc=max(Acc);
        fprintf('\n Accuracy: %g %%',Acc*100);
        ACC_MPG(ci)=Acc;
        t2 = clock;
        toc;
        time = etime(t2, t1);
        all_testPF=[all_testPF;testPF];

        save(strcat('result-', dataNames{dN}, '-', num2str(ci)), 'x', 'selFeatNum', 'Acc', 'time','testPF','HV_MPG','mean_HV_MPG','std_HV_MPG','all_testPF');
        save(strcat('result-', dataNames{dN}, '-HV_PF'), 'HV_MPG','mean_HV_MPG','std_HV_MPG','all_testPF','ACC_MPG');
        ind={};
        tr_ind={};
        train_ind=[];
        te_ind={};
        test_ind=[];
        xx=[];
        fit=[];
        all_testPF=[];



    end


    load (strcat('result-', dataNames{dN}, '-', 'HV_PF'));
    % dataNames = {'Brain2'};
    [all_FrontNo, ~] = NDSort(all_testPF,size(all_testPF, 1));
    all_Front1 = all_FrontNo' == 1;
    all_run_testPF=all_testPF(all_Front1,: );
    save(strcat('MOEA-', dataNames{dN},'-ACC'), 'ACC_MPG');
    save(strcat('MOEA-',dataNames{dN}, '-HV'), 'mean_HV_MPG','std_HV_MPG','HV_MPG');
    save(strcat('MOEA-',dataNames{dN}, 'testPF'), 'all_run_testPF','all_testPF');
end
