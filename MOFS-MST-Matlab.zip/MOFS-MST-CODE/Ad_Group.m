function [newg,pop]=Ad_Group(x ,g , pop ,maxP)
groupNum = numel(g);

c=1;

for j = 1 : groupNum
    a_1=sum(x(1, g{j}));
    num=length(g{j});
    if a_1 == num || a_1 == 0
        
        newg{c} = g{j};
        c=c+1;
        
    else
        
        f1=find(x(1,g{j})==1);
        f0=find(x(1,g{j})==0);
        f11=g{1,j}(f1,:);
        f00=g{1,j}(f0,:);
        newg{c} = f11;
        newg{c+1}= f00;
        c=c+2;
        
    end
end
pop(maxP,:)=x;
end

