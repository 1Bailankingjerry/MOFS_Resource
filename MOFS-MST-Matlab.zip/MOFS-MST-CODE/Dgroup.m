function [g1,g2,pop1,pop2]=Dgroup(g1,g2,pop1,pop2,featNum)

        x1=group_x(g1,pop1,featNum);
        x2=group_x(g2,pop2,featNum);
    
    g1=splitgroup(g1);
    g2=splitgroup(g2);

    
    pop1=x_group(g1,x1);
    pop2=x_group(g2,x2);
    
end