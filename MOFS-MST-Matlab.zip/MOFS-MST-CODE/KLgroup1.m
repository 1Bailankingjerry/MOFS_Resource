function [pop1,pop2,g1,g2,eg] =  KLgroup1(g1,g2,objs_1,objs_2,pop1,pop2,featNum,eg)


sg2=sum(pop2);

[out2,ff2] = sort(sg2,'descend');


m2=1;
xia2=0;
if isempty(eg)==0
    while xia2<1

        f2=ff2(1,m2);

        Msg22=g2{1,f2};

        a2=min(length(eg),length(Msg22));

        for j=1:a2
            b2=find(eg==Msg22(j));
            if isempty(b2)==1
                xia2=xia2+1;
                Msg2{1,xia2}=g2{1,f2};
            end
        end
        m2=m2+1;
    end
else
    m2=1;
    for i=1:m2
        f2=ff2(1,i);

        Msg2{1,i}=g2{1,f2};
    end
end


F1=zeros(1,featNum);



len1=numel(g1);



for i=1:len1
    F1(1,g1{i})=i;
end



c=1;
for j=1:numel(Msg2)
    ktg1=Msg2{1,j};
    for i=1:length(ktg1)
        a1=F1(1,ktg1(i));
        n1=find(F1==a1);
        if length(n1)>1
            F1(1,ktg1(i))=len1+c;
        end
    end
    re1=find(F1==len1+c);
    if isempty(re1)==0
        c=c+1;
    end
end



for i=1:max(F1)

    g1{i}=find(F1==i)';


end



[FrontNo1, ~] = NDSort(objs_1,size(objs_1, 1));
NNF1=FrontNo1' ~= 1;


if numel(g1)>len1
    addg1=numel(g1)-len1;
    for i=1:addg1
        pop1(NNF1,len1+i)=1;
    end
end
for i=1:numel(Msg2)

    eg=[eg;Msg2{1,i}];
end
[~, uni] = unique(eg, 'rows');
eg=eg(uni,:);
end


