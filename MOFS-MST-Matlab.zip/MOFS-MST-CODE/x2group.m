function x2 = x2group(g, x,assess)
% popNum = size(x, 1);
% groupNum = numel(g);
% p=1;
% x2 = zeros(popNum, groupNum);
% for i = 1 : popNum
%     for j = 1 : groupNum
%         a_1=sum(x(i, g{j}));
% 
%        f_1=find(x(i, g{j})==1);
%        f_0=find(x(i, g{j})==0);
%         num=length(g{j});
%         if a_1 == num || a_1 == 0
% 
%             x2(i, j) = max(x(i, g{j}));
% 
%         else
% %             avg=(mean(assess(g{1,j}(f_1,:),1))+mean(assess(g{1,j}(f_0,:),2)))/(2*num);
% 
%             if mean(assess(g{1,j}(f_1,:),1))>mean(assess(g{1,j}(f_0,:),2))
%                 x2(i, j)=1;
% 
%             else
%                 x2(i, j)=0;
% 
%             end
%         end
%     end
% 
% end
popNum = size(x, 1);
groupNum = numel(g);

x2 = zeros(popNum, groupNum);
for i = 1 : popNum
    for j = 1 : groupNum
        a_1=sum(x(i, g{j}));
        if length(x(i, g{j})) ==1
            x2(i,j)=max(x(i, g{j}));
        else
        Th_1=ceil(length(x(i, g{j}))/2);
        if a_1>Th_1
            x2(i,j)=1;
        else
            x2(i,j)=0;
        end
        end
    end
end


end