This file involves the single-objective version of the evolutionary NCA code. We also provided the PSO algorithm as well as the DE algorithm. 

For running the DE algorithm, please install the PlatEMO toolbox.
