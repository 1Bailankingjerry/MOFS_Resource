# DENCA and MODENCA
Emrah Hancer, Bing Xue, Mengjie Zhang,
An evolutionary filter approach to feature selection in classification for both single- and multi-objective scenarios,
Knowledge-Based Systems,
2023,
111008,
ISSN 0950-7051,
https://doi.org/10.1016/j.knosys.2023.111008.
(https://www.sciencedirect.com/science/article/pii/S095070512300758X)

**For running the multi-objective version**, please see run_mode

**For running the single-objective version**, please see single_objective_scenario/psorun and single_objective_scenario/derun
