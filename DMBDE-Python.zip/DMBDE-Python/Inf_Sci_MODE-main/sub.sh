sbatch jobs.sl dataSet_SPECT
sbatch jobs.sl dataSet_ion
sbatch jobs.sl dataSet_leukemia1
sbatch jobs.sl dataSet_leukemia2
# sbatch jobs.sl dataSet_sonar
# sbatch jobs.sl dataSet_move
# sbatch jobs.sl dataSet_hill
# sbatch jobs.sl dataSet_musk1
# sbatch jobs.sl dataSet_multiple
# sbatch jobs.sl dataSet_arrhythmia
# sbatch jobs.sl dataSet_madelon
# sbatch jobs.sl dataSet_SRBCT
# sbatch jobs.sl dataSet_leukemia
# sbatch jobs.sl dataSet_Prostate
# sbatch jobs.sl dataSet_11Tumor
# sbatch jobs.sl dataSet_LungCancer
# sbatch jobs.sl dataSet_14Tumor
# sbatch jobs.sl dataSet_AD
# sbatch jobs.sl dataSet_9Tumor
# sbatch jobs.sl dataSet_DLBCL
# sbatch jobs.sl dataSet_CNAE
# sbatch jobs.sl dataSet_Brain1
# sbatch jobs.sl dataSet_Brain2
