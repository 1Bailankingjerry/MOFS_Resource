# Inf_Sci_MODE

Diversity-based Binary MODE Feature Selection

We are more than happy to share the related Python codes with you. If you do some further studies based on this research work, please cite this study as a reference in your papers.

Please feel free to contact me if you have any questions or comments (wangpeng@ecs.vuw.ac.nz).

Also, please change the classifiers used in the codes accordingly.
