for ((i=26536041;i<=26536052;i++))
do
scancel $i
done
